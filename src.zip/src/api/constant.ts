export const BASE_URL = 'https://api.themoviedb.org/3';
