export const IMAGE_BASE_URL = 'https://image.tmdb.org/t/p';
