export const IMAGE_BASE_URL = 'https://image.tmdb.org/t/p';
export const BASE_URL = 'https://api.themoviedb.org/3';
export const INITIAL_PAGE = 1;
export const MOVIE_INDEX_FOR_BANNER = 1;
export const TOTAL_PAGES = 500;
